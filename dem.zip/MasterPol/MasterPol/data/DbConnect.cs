﻿using MasterPol.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MasterPol.data
{
    internal class DbConnect
    {
        
    }
}
