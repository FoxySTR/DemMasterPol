﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MasterPol.Models
{
    internal class Partner
    {
        public int id { get; set; }
        public string PartnerType { get; set; }
        public string PartnerName { get; set; }
        public string Director { get; set; }
        public string EmailPartner { get; set; }
        public string Telephone { get; set; }
        public string Address { get; set; }
        public int Inn { get; set; }
        public int rating { get; set; }
    }
}
