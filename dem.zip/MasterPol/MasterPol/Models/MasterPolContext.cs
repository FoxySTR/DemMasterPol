﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MasterPol.Models
{
    internal class MasterPolContext: DbContext
    {
        public virtual DbSet<History> histories { get; set; }
        public virtual DbSet<MaterialType> MaterialTypes { get; set; }
        public virtual DbSet<Partner> Partners { get; set; }
        public virtual DbSet<Product> Products { get; set; }
        public virtual DbSet<ProductType> ProductTypes { get; set; }

        public MasterPolContext()
        {
            Database.EnsureCreated();
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlite("Data Source=helloapp.db");
            //optionsBuilder.UseSqlServer("Data Source=192.168.1.2,5434;Initial Catalog=CarService;User ID=470;Password=GzsAsiOBjK;Trust Server Certificate=True");
        }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            List<ProductType> productTypes = [];
            
            
            using var file = File.Open("C:\\Users\\user.COM304-16\\Documents\\475\\MasterPol\\MasterPol\\Import\\Product_type_import.csv", FileMode.Open);

            using var reader = new StreamReader(file);

            while (!reader.EndOfStream)
            {
                var line = reader.ReadLine()?.Split(';');

                productTypes.Add(new ProductType
                {
                    Id = int.Parse(line[0]),
                    Name = line[1],
                    Coefficient = decimal.Parse(line[2]),
                });

            }
            modelBuilder.Entity<ProductType>().HasData(productTypes);



            List<Product> Products = [];

            using var file1 = File.Open("C:\\Users\\user.COM304-16\\Documents\\475\\MasterPol\\MasterPol\\Import\\Products_import.csv", FileMode.Open);
            using var reader1 = new StreamReader(file1);

            while (!reader1.EndOfStream)
            {

                var line = reader1.ReadLine()?.Split(';');
                Products.Add(new Product
                {
                    Id = int.Parse(line[0]),
                    TypeId = int.Parse(line[1]),
                    ProductName = line[2],
                    Artic = int.Parse(line[3]),
                    MinPrice = line[4],
                });

            }
            modelBuilder.Entity<Product>().HasData(Products);






        }




    }
}
