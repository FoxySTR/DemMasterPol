﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace MasterPol.Models
{
    internal class MaterialType
    {
        public int id {  get; set; }
        public string Type { get; set; }
        public double Procent {  get; set; }

    }
}
