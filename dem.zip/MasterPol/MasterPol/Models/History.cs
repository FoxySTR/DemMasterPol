﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MasterPol.Models
{
    internal class History
    {
        public int Id { get; set; }
        public Product name { get; set; }
        public Partner partner { get; set; }
        public int count { get; set; }
        public DateTime date { get; set; }

    }
}
